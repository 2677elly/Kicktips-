KICKTIPS — ANDROID INSTALLABLE WEB APP

This package is a Progressive Web App (PWA), not a standalone APK.
It must be published to an HTTPS website before Chrome offers Install / Add to Home screen.

FILES
- index.html: public tips page
- manifest.webmanifest: install name, theme and icons
- sw.js: basic offline app-shell caching
- icons/: app icons

FREE PUBLISHING ROUTE (Android phone)
1. Upload ALL files and folders in this ZIP to a static hosting service that provides an HTTPS URL (for example GitHub Pages or Netlify).
2. Keep the folder structure unchanged. The index.html, manifest.webmanifest, sw.js, and icons folder must be at the published site root.
3. Open the HTTPS website in Google Chrome on Android.
4. Tap Chrome's three-dot menu, then "Install app" or "Add to Home screen", and confirm.
5. The KickTips icon will appear on your phone. Open it like an app.

IMPORTANT
- This public page loads tips from tips.json if you publish that file; otherwise it shows a sample placeholder. Replace the sample before sharing publicly.
- The separate admin editor is not included in this public-only install package.
- This does not create an APK file or publish the website for you.
- Betting predictions are uncertain; no tip guarantees a win. Only adults should bet and never borrow money to gamble.
